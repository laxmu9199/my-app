# AWS CDK CI/CD Pipeline → EKS

A production-ready CDK (TypeScript) project that provisions a full CI/CD pipeline on AWS:

```
GitHub Push → CodePipeline → CodeBuild (Docker build → ECR) → CodeBuild (kubectl → EKS)
```

## Stack Overview

| Stack | What it creates |
|---|---|
| `EcrStack` | ECR repository with image scanning & lifecycle rules |
| `EksStack` | VPC, EKS 1.31 cluster, managed node group, IAM deploy role |
| `PipelineStack` | CodePipeline with GitHub source, build, and EKS deploy stages |

---

## Prerequisites

- Node.js 18+
- AWS CLI configured (`aws configure`)
- CDK CLI: `npm install -g aws-cdk`
- AWS account bootstrapped: `cdk bootstrap`

---

## One-Time Setup: GitHub Connection

The pipeline uses **AWS CodeStar Connections** to securely pull from GitHub.

1. Go to **AWS Console → CodePipeline → Settings → Connections**
2. Create a connection for GitHub and authorize it
3. Copy the connection ARN — you'll need it below

---

## Deploy

```bash
npm install

# Deploy all stacks (pass your values via context)
cdk deploy --all \
  -c githubOwner=your-org \
  -c githubRepo=your-repo \
  -c githubBranch=main \
  -c codeStarConnectionArn=arn:aws:codestar-connections:us-east-1:123456789012:connection/xxxxx
```

Or deploy stacks individually:

```bash
npm run deploy:ecr
npm run deploy:eks       # ~15 min for EKS cluster
npm run deploy:pipeline
```

---

## How the Pipeline Works

### Stage 1 — Source
Triggered on every push to the configured branch. Uses the CodeStar Connection to pull from GitHub.

### Stage 2 — Build
CodeBuild:
- Logs into ECR
- Runs `docker build`
- Tags image with the short Git commit hash
- Pushes `latest` + `<commit-hash>` tags to ECR
- Outputs `imagedefinitions.json` and `image.env` for the deploy stage

### Stage 3 — Deploy
CodeBuild:
- Installs `kubectl`
- Assumes the `eks-deploy-role` IAM role
- Runs `aws eks update-kubeconfig`
- Substitutes the image tag into `k8s/deployment.yaml`
- Runs `kubectl apply -f k8s/`
- Waits for rollout to complete (`kubectl rollout status`)

---

## Kubernetes Manifests

Located in `k8s/`:

- `deployment.yaml` — 2-replica deployment with rolling updates, liveness/readiness probes
- `service.yaml` — NLB-backed LoadBalancer service on port 80

The `IMAGE_TAG_PLACEHOLDER` string in `deployment.yaml` is replaced by the deploy stage with the actual ECR image URI.

---

## Customisation Tips

- **Add a test stage**: insert a CodeBuild project between Build and Deploy that runs `npm test` or `pytest`
- **Multi-environment**: duplicate the deploy stage with a manual approval action in between for staging → production promotion
- **Helm**: swap the `kubectl apply` commands in the deploy buildspec for `helm upgrade --install`
- **Notifications**: add an SNS topic + `SlackChannelConfiguration` construct to get pipeline alerts in Slack

---

## Teardown

```bash
cdk destroy --all
```

> **Note:** The ECR repository has `RemovalPolicy.RETAIN` to prevent accidental image loss. Delete it manually if needed.
