import * as cdk from "aws-cdk-lib";
import * as ec2 from "aws-cdk-lib/aws-ec2";
import * as eks from "aws-cdk-lib/aws-eks";
import * as iam from "aws-cdk-lib/aws-iam";
import { Construct } from "constructs";

export class EksStack extends cdk.Stack {
  public readonly cluster: eks.Cluster;

  constructor(scope: Construct, id: string, props: cdk.StackProps) {
    super(scope, id, props);

    // Dedicated VPC for the cluster
    const vpc = new ec2.Vpc(this, "EksVpc", {
      maxAzs: 2,
      natGateways: 1,
      subnetConfiguration: [
        { name: "public", subnetType: ec2.SubnetType.PUBLIC, cidrMask: 24 },
        {
          name: "private",
          subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS,
          cidrMask: 24,
        },
      ],
    });

    // EKS cluster (nodes live in private subnets)
    this.cluster = new eks.Cluster(this, "AppCluster", {
      clusterName: "app-cluster",
      version: eks.KubernetesVersion.V1_31,
      vpc,
      vpcSubnets: [{ subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS }],
      defaultCapacity: 0, // managed node group below
      endpointAccess: eks.EndpointAccess.PUBLIC_AND_PRIVATE,
    });

    // Managed node group
    this.cluster.addNodegroupCapacity("AppNodes", {
      instanceTypes: [new ec2.InstanceType("t3.medium")],
      minSize: 2,
      maxSize: 6,
      desiredSize: 2,
      diskSize: 50,
      amiType: eks.NodegroupAmiType.AL2_X86_64,
      subnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
    });

    // IAM role that CodeBuild will assume to run kubectl
    const deployRole = new iam.Role(this, "EksDeployRole", {
      roleName: "eks-deploy-role",
      assumedBy: new iam.AccountPrincipal(this.account),
      description: "Assumed by CodeBuild to deploy to EKS",
    });

    // Grant the deploy role access to the cluster
    this.cluster.awsAuth.addRoleMapping(deployRole, {
      groups: ["system:masters"],
    });

    new cdk.CfnOutput(this, "ClusterName", {
      value: this.cluster.clusterName,
      exportName: "EksClusterName",
    });

    new cdk.CfnOutput(this, "DeployRoleArn", {
      value: deployRole.roleArn,
      exportName: "EksDeployRoleArn",
    });
  }
}
