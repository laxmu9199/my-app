import * as cdk from "aws-cdk-lib";
import * as codebuild from "aws-cdk-lib/aws-codebuild";
import * as codepipeline from "aws-cdk-lib/aws-codepipeline";
import * as actions from "aws-cdk-lib/aws-codepipeline-actions";
import * as ecr from "aws-cdk-lib/aws-ecr";
import * as eks from "aws-cdk-lib/aws-eks";
import * as iam from "aws-cdk-lib/aws-iam";
import { Construct } from "constructs";

interface PipelineStackProps extends cdk.StackProps {
  ecrRepository: ecr.Repository;
  eksCluster: eks.Cluster;
  githubOwner: string;
  githubRepo: string;
  githubBranch: string;
  codeStarConnectionArn: string;
}

export class PipelineStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: PipelineStackProps) {
    super(scope, id, props);

    const {
      ecrRepository,
      eksCluster,
      githubOwner,
      githubRepo,
      githubBranch,
      codeStarConnectionArn,
    } = props;

    // ── Artifacts ────────────────────────────────────────────────────────────
    const sourceArtifact = new codepipeline.Artifact("Source");
    const buildArtifact = new codepipeline.Artifact("Build");

    // ── Build project: Docker build → push to ECR ────────────────────────────
    const buildProject = new codebuild.PipelineProject(this, "BuildProject", {
      projectName: "app-build",
      environment: {
        buildImage: codebuild.LinuxBuildImage.STANDARD_7_0,
        privileged: true, // required for Docker daemon
        environmentVariables: {
          REPOSITORY_URI: { value: ecrRepository.repositoryUri },
          AWS_DEFAULT_REGION: { value: this.region },
          AWS_ACCOUNT_ID: { value: this.account },
        },
      },
      buildSpec: codebuild.BuildSpec.fromObject({
        version: "0.2",
        phases: {
          pre_build: {
            commands: [
              "echo Logging in to Amazon ECR...",
              "aws ecr get-login-password --region $AWS_DEFAULT_REGION | docker login --username AWS --password-stdin $AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com",
              "COMMIT_HASH=$(echo $CODEBUILD_RESOLVED_SOURCE_VERSION | cut -c 1-7)",
              "IMAGE_TAG=${COMMIT_HASH:=latest}",
            ],
          },
          build: {
            commands: [
              "echo Building Docker image...",
              "docker build -t $REPOSITORY_URI:latest .",
              "docker tag $REPOSITORY_URI:latest $REPOSITORY_URI:$IMAGE_TAG",
            ],
          },
          post_build: {
            commands: [
              "echo Pushing Docker image...",
              "docker push $REPOSITORY_URI:latest",
              "docker push $REPOSITORY_URI:$IMAGE_TAG",
              // Write image tag to file for the deploy stage
              'printf \'[{"name":"app","imageUri":"%s"}]\' $REPOSITORY_URI:$IMAGE_TAG > imagedefinitions.json',
              "echo IMAGE_TAG=$IMAGE_TAG > image.env",
            ],
          },
        },
        artifacts: {
          files: ["imagedefinitions.json", "image.env", "k8s/**/*"],
        },
      }),
    });

    ecrRepository.grantPullPush(buildProject);

    // ── Deploy project: kubectl apply to EKS ─────────────────────────────────
    const deployRole = iam.Role.fromRoleName(
      this,
      "EksDeployRole",
      "eks-deploy-role"
    );

    const deployProject = new codebuild.PipelineProject(this, "DeployProject", {
      projectName: "app-deploy",
      environment: {
        buildImage: codebuild.LinuxBuildImage.STANDARD_7_0,
        environmentVariables: {
          CLUSTER_NAME: { value: eksCluster.clusterName },
          AWS_DEFAULT_REGION: { value: this.region },
          DEPLOY_ROLE_ARN: { value: deployRole.roleArn },
        },
      },
      buildSpec: codebuild.BuildSpec.fromObject({
        version: "0.2",
        phases: {
          install: {
            commands: [
              // Install kubectl
              'curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"',
              "chmod +x kubectl && mv kubectl /usr/local/bin/",
            ],
          },
          pre_build: {
            commands: [
              // Assume the EKS deploy role
              "CREDS=$(aws sts assume-role --role-arn $DEPLOY_ROLE_ARN --role-session-name CodeBuildDeploy)",
              'export AWS_ACCESS_KEY_ID=$(echo $CREDS | jq -r .Credentials.AccessKeyId)',
              'export AWS_SECRET_ACCESS_KEY=$(echo $CREDS | jq -r .Credentials.SecretAccessKey)',
              'export AWS_SESSION_TOKEN=$(echo $CREDS | jq -r .Credentials.SessionToken)',
              // Configure kubeconfig
              "aws eks update-kubeconfig --region $AWS_DEFAULT_REGION --name $CLUSTER_NAME",
            ],
          },
          build: {
            commands: [
              // Load image tag from build stage
              "source image.env",
              // Substitute image tag in manifests and apply
              "sed -i 's|IMAGE_TAG_PLACEHOLDER|'$IMAGE_TAG'|g' k8s/deployment.yaml",
              "kubectl apply -f k8s/",
              "kubectl rollout status deployment/app -n default --timeout=5m",
            ],
          },
        },
      }),
    });

    // Allow the deploy project to assume the EKS deploy role
    deployProject.addToRolePolicy(
      new iam.PolicyStatement({
        actions: ["sts:AssumeRole"],
        resources: [deployRole.roleArn],
      })
    );

    // ── Pipeline ─────────────────────────────────────────────────────────────
    const pipeline = new codepipeline.Pipeline(this, "AppPipeline", {
      pipelineName: "app-pipeline",
      crossAccountKeys: false, // cheaper; single-account setup
      restartExecutionOnUpdate: true,
    });

    // Stage 1: Source (GitHub via CodeStar Connection)
    pipeline.addStage({
      stageName: "Source",
      actions: [
        new actions.CodeStarConnectionsSourceAction({
          actionName: "GitHub_Source",
          owner: githubOwner,
          repo: githubRepo,
          branch: githubBranch,
          connectionArn: codeStarConnectionArn,
          output: sourceArtifact,
          triggerOnPush: true,
        }),
      ],
    });

    // Stage 2: Build
    pipeline.addStage({
      stageName: "Build",
      actions: [
        new actions.CodeBuildAction({
          actionName: "Docker_Build_Push",
          project: buildProject,
          input: sourceArtifact,
          outputs: [buildArtifact],
        }),
      ],
    });

    // Stage 3: Deploy
    pipeline.addStage({
      stageName: "Deploy",
      actions: [
        new actions.CodeBuildAction({
          actionName: "Deploy_to_EKS",
          project: deployProject,
          input: buildArtifact,
        }),
      ],
    });

    new cdk.CfnOutput(this, "PipelineUrl", {
      value: `https://${this.region}.console.aws.amazon.com/codesuite/codepipeline/pipelines/app-pipeline/view`,
    });
  }
}
