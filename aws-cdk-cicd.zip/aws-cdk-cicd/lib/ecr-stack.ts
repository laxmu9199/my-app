import * as cdk from "aws-cdk-lib";
import * as ecr from "aws-cdk-lib/aws-ecr";
import { Construct } from "constructs";

export class EcrStack extends cdk.Stack {
  public readonly repository: ecr.Repository;

  constructor(scope: Construct, id: string, props: cdk.StackProps) {
    super(scope, id, props);

    this.repository = new ecr.Repository(this, "AppRepository", {
      repositoryName: "app",
      removalPolicy: cdk.RemovalPolicy.RETAIN,
      imageScanOnPush: true,
      lifecycleRules: [
        {
          // Keep only the last 10 tagged images
          maxImageCount: 10,
          tagStatus: ecr.TagStatus.ANY,
          description: "Retain last 10 images",
        },
        {
          // Expire untagged images after 7 days
          maxImageAge: cdk.Duration.days(7),
          tagStatus: ecr.TagStatus.UNTAGGED,
          description: "Expire untagged images",
        },
      ],
    });

    new cdk.CfnOutput(this, "RepositoryUri", {
      value: this.repository.repositoryUri,
      exportName: "EcrRepositoryUri",
    });
  }
}
